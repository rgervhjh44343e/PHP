<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <a href="form.html">Back to Form</a>
<?php
    $name = "";
    $email = "";
    if(isset($_POST['name']))
        $name = $_POST['name'];
    if(isset($_POST['email']))
        $email = $_POST['email'];
    echo "<br/>Name: " . $name . " - Email: " . $email;
    $output = $name . "#" . $email . "\n";
    $file = fopen("/LyThanhKy_2080600423/formdata.txt", "a");
    if($file) {
        fwrite($file, $output);
        fclose($file);
        echo "Dữ liệu đã được ghi vào tệp tin!";
    } else {
        echo "Không thể mở hoặc tạo tệp tin để ghi!";
    }
    ?>
</body>
</html>